const { sequelize, Support } = require('../models/sequelize');
const Stripe = require("stripe");
const stripe = new Stripe(process.env.STRIPE_MODE);

module.exports.index = async(req, res, next) =>{
  try {
    const queryType = req.params.type === '2' ? 'createdAt' : 'total';
    const [data, meta] = await sequelize.query(`
      SELECT 
        ${req.params.type === '2' ? 'U.name as user_name, S.createdAt' : 'S.id, U.name as user_name, sum(S.amount) as total'}
      FROM Supports S
      INNER JOIN Users U ON U.id = S.id_user
      WHERE S.id_organization = ${req.params.id}
      ${req.params.type !== '2' ? 'GROUP BY S.id_user' : ''}
      ORDER BY ${queryType} DESC
    `);
    return res.json(data);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).send('Error interno del servidor');
  }
};

module.exports.create = async (req, res) => {
  const {
    amount,
    amount_radi,
    visible,
    customer,
    id_user,
    account,
    id_organization,
    org_name,
  } = req.body;
  
  const pricing = amount + amount_radi * amount;

  try {
    const responseStripe = await stripe.charges.create({
      amount: Math.round(pricing * 100),
      currency: "Mxn",
      customer,
      application_fee_amount: Math.round(pricing * 100 * 0.1899),
      transfer_data: {
        destination: account,
      },
      description: `Apoyo a ${org_name}`,
    });

    if (responseStripe.status === "succeeded") {
      const supportData = {
        amount,
        amount_radi,
        visible,
        payment: responseStripe.id,
        id_user,
        id_organization,
        status: 1,
      };

      const createdSupport = await Support.create(supportData);
      res.status(200).json({ message: 'Success', status: 200, data: createdSupport });
    }
  } catch (error) {
    console.error('Error:', error);
    res.status(503).send(error);
  }
};

module.exports.byUser = async (req, res) => {
  try {
    const supportData = await Support.findAll({
      where: {
        id_user: req.params.id,
      },
      order: [['id', 'DESC']],
    });
    return res.json(supportData);
  } catch (error) {
    console.error('Error:', error);
    res.status(503).send(error);
  }
};