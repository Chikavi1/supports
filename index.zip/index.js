const serverless = require("serverless-http");
const express = require("express");
const app = express();

app.use(express.json());
const routes = require('./routes');
app.use('/', routes());

// Borrar al subir
app.listen('8080','0.0.0.0',() => {
    console.log('Servido iniciado.');
});


module.exports.handler = serverless(app);
