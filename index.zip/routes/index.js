const express = require('express');
const router = express.Router();
const IndexController = require('../controller/IndexController');

module.exports = function(){
    router.get('/index/:id/:type', IndexController.index);
    router.post('/create', IndexController.create);
    router.get('/byUser/:id', IndexController.byUser);
    return router;
}